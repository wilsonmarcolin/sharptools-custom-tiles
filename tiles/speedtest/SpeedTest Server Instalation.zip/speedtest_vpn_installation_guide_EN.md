# Installation Guide - Multi-Regional Speedtest System with VPN

## Overview
Automated system for performing internet speed tests in 3 regions (Panama, Brazil, and USA) using ExpressVPN to simulate different locations.

---

## 1. PREREQUISITES

### 1.1 Required Software
- Windows 10 or higher
- **ExpressVPN Windows app** (must be installed, activated, and logged in BEFORE running scripts)
- Python 3.13+ 
- Administrative access to Windows

### 1.2 Network Configuration
- Fixed IP configured: 192.168.1.5
- Port 9001 open in firewall

### 1.3 ExpressVPN Account Requirements
- Active ExpressVPN subscription
- Your ExpressVPN login credentials (email/password) OR activation code
- Internet connection for initial activation

---

## 2. PYTHON INSTALLATION

### 2.1 Download and Install Python
1. Go to https://www.python.org/downloads/
2. Download Python 3.13 or higher
3. During installation:
   - ✅ Check "Add Python to PATH"
   - Choose "Install Now"

### 2.2 Verify Installation
```powershell
python --version
```

---

## 3. SPEEDTEST CLI INSTALLATION (OFFICIAL OOKLA)

### 3.1 Download and Install
Run in PowerShell as Administrator:

```powershell
# Create scripts directory
New-Item -ItemType Directory -Force -Path C:\scripts
cd C:\scripts

# Download Speedtest CLI
Invoke-WebRequest -Uri "https://install.speedtest.net/app/cli/ookla-speedtest-1.2.0-win64.zip" -OutFile "speedtest.zip"

# Extract
Expand-Archive -Path "speedtest.zip" -DestinationPath "speedtest" -Force

# Test
C:\scripts\speedtest\speedtest.exe --accept-license --accept-gdpr
```

---

## 4. EXPRESSVPN INSTALLATION AND CONFIGURATION

### 4.1 Installing ExpressVPN (REQUIRED FIRST STEP)

#### Step 1: Download and Install
1. Go to https://www.expressvpn.com/vpn-software/vpn-windows
2. Download the ExpressVPN installer for Windows
3. Run the installer as Administrator
4. Follow the installation wizard

#### Step 2: Activate Your Account
1. Open ExpressVPN from the Start Menu
2. Click "Sign In"
3. Enter your ExpressVPN email and password
4. OR use your activation code (found in your ExpressVPN account)
5. Wait for activation to complete

#### Step 3: Test Manual Connection
1. In the ExpressVPN app, click the connection button
2. Connect to any location to verify it works
3. Disconnect
4. **IMPORTANT:** Keep ExpressVPN running in the system tray (do not exit completely)

#### Step 4: Verify CLI Installation
After ExpressVPN is installed and activated, verify the CLI exists:
```powershell
# Check if CLI exists
Test-Path "C:\Program Files (x86)\ExpressVPN\services\ExpressVPN.CLI.exe"
```

### 4.2 CLI Location
ExpressVPN CLI is automatically installed at:
```
C:\Program Files (x86)\ExpressVPN\services\ExpressVPN.CLI.exe
```

### 4.3 VPN Location IDs
These IDs will be used by the scripts:
- **Brazil:** ID 163 (Brazil - 2)
- **USA:** ID 202 (USA - Miami - 2)

### 4.4 Test CLI Commands
Only after ExpressVPN is installed and activated, test these commands:
```powershell
& "C:\Program Files (x86)\ExpressVPN\services\ExpressVPN.CLI.exe" status
& "C:\Program Files (x86)\ExpressVPN\services\ExpressVPN.CLI.exe" connect 163
& "C:\Program Files (x86)\ExpressVPN\services\ExpressVPN.CLI.exe" disconnect
```

---

## 5. MAIN SCRIPTS

### 5.1 Main Webhook Script
Create file `C:\scripts\speedtest_webhook.py`:

```python
import http.server
import json
import subprocess
import time
import os
from datetime import datetime
from urllib.parse import urlparse, parse_qs

# Configuration
VALID_TOKEN = "UgaJMc9vaJxU7J9GucZ4JvdUbdTahC99"
EXPRESSVPN_CLI = "C:\\Program Files (x86)\\ExpressVPN\\services\\ExpressVPN.CLI.exe"
SPEEDTEST_EXE = "C:\\scripts\\speedtest\\speedtest.exe"
RESULTS_FILE = "C:\\scripts\\speedtest_results.json"

# VPN IDs
VPN_BRAZIL = "163"
VPN_USA = "202"

# Speedtest Servers
SERVERS = {
    "panama": {"id": "31830", "name": "Ufinet"},
    "brazil": {"id": "16322", "name": "Claro SP"},
    "usa": {"id": "68862", "name": "AT&T Orlando"}
}

def vpn_connect(vpn_id):
    subprocess.run(f'"{EXPRESSVPN_CLI}" connect {vpn_id}', shell=True, capture_output=True, timeout=30)
    time.sleep(8)
    return {"status": "connected", "vpn_id": vpn_id}

def vpn_disconnect():
    subprocess.run(f'"{EXPRESSVPN_CLI}" disconnect', shell=True, capture_output=True, timeout=30)
    time.sleep(3)
    return {"status": "disconnected"}

def vpn_status():
    result = subprocess.run(f'"{EXPRESSVPN_CLI}" status', shell=True, capture_output=True, text=True, timeout=10)
    return {"output": result.stdout.strip()}

def run_speedtest(server_id):
    try:
        cmd = f'"{SPEEDTEST_EXE}" --accept-license --accept-gdpr -s {server_id} -f json'
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=90)
        
        if result.returncode == 0:
            data = json.loads(result.stdout)
            return {
                "success": True,
                "download": round(data["download"]["bandwidth"] * 8 / 1_000_000, 2),
                "upload": round(data["upload"]["bandwidth"] * 8 / 1_000_000, 2),
                "ping": round(data["ping"]["latency"], 2),
                "server": data["server"]["name"],
                "timestamp": datetime.now().isoformat()
            }
    except:
        pass
    return {"success": False}

def save_results(region, result):
    results = {}
    if os.path.exists(RESULTS_FILE):
        with open(RESULTS_FILE, "r") as f:
            results = json.load(f)
    
    if region not in results:
        results[region] = []
    
    results[region].append(result)
    if len(results[region]) > 24:  # Keep last 24 measurements
        results[region] = results[region][-24:]
    
    with open(RESULTS_FILE, "w") as f:
        json.dump(results, f, indent=2)

class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        if "GET /hooks" in str(args):
            print(f"[{datetime.now().strftime('%H:%M:%S')}] {args[0].split('?')[0]}")
    
    def do_GET(self):
        path = urlparse(self.path).path
        token = parse_qs(urlparse(self.path).query).get('token', [''])[0]
        
        if path.startswith('/hooks/') and token != VALID_TOKEN:
            self.send_error(401)
            return
        
        # VPN CONTROL
        if path == '/hooks/vpn-brazil-on':
            print("[VPN] Connecting Brazil...")
            result = vpn_connect(VPN_BRAZIL)
            self.send_json(result)
            
        elif path == '/hooks/vpn-usa-on':
            print("[VPN] Connecting USA...")
            result = vpn_connect(VPN_USA)
            self.send_json(result)
            
        elif path == '/hooks/vpn-off':
            print("[VPN] Disconnecting...")
            result = vpn_disconnect()
            self.send_json(result)
            
        elif path == '/hooks/vpn-status':
            result = vpn_status()
            self.send_json(result)
        
        # INDIVIDUAL TESTS
        elif path == '/hooks/test-panama':
            print("[TEST] Panama - Ufinet")
            result = run_speedtest(SERVERS["panama"]["id"])
            if result["success"]:
                save_results("panama", result)
            self.send_json(result)
            
        elif path == '/hooks/test-brazil':
            print("[TEST] Brazil - Claro")
            result = run_speedtest(SERVERS["brazil"]["id"])
            if result["success"]:
                save_results("brazil", result)
            self.send_json(result)
            
        elif path == '/hooks/test-usa':
            print("[TEST] USA - AT&T")
            result = run_speedtest(SERVERS["usa"]["id"])
            if result["success"]:
                save_results("usa", result)
            self.send_json(result)
        
        # COMPLETE SEQUENCES
        elif path == '/hooks/sequence-brazil':
            print("[SEQ] Brazil: VPN On → Test → VPN Off")
            vpn_connect(VPN_BRAZIL)
            result = run_speedtest(SERVERS["brazil"]["id"])
            if result["success"]:
                save_results("brazil", result)
            vpn_disconnect()
            self.send_json(result)
            
        elif path == '/hooks/sequence-usa':
            print("[SEQ] USA: VPN On → Test → VPN Off")
            vpn_connect(VPN_USA)
            result = run_speedtest(SERVERS["usa"]["id"])
            if result["success"]:
                save_results("usa", result)
            vpn_disconnect()
            self.send_json(result)
            
        elif path == '/hooks/test-all':
            print("[SEQ] Complete test: Panama → Brazil → USA")
            results = {}
            
            # Panama
            r = run_speedtest(SERVERS["panama"]["id"])
            if r["success"]:
                results["panama"] = r
                save_results("panama", r)
            
            # Brazil
            vpn_connect(VPN_BRAZIL)
            r = run_speedtest(SERVERS["brazil"]["id"])
            if r["success"]:
                results["brazil"] = r
                save_results("brazil", r)
            vpn_disconnect()
            
            # USA
            vpn_connect(VPN_USA)
            r = run_speedtest(SERVERS["usa"]["id"])
            if r["success"]:
                results["usa"] = r
                save_results("usa", r)
            vpn_disconnect()
            
            self.send_json(results)
            
        elif path == '/hooks/results':
            if os.path.exists(RESULTS_FILE):
                with open(RESULTS_FILE, "r") as f:
                    results = json.load(f)
                    summary = {}
                    for region in ["panama", "brazil", "usa"]:
                        if region in results and results[region]:
                            summary[region] = results[region][-1]
                    self.send_json(summary)
            else:
                self.send_json({})
        
        else:
            self.send_error(404)
    
    def send_json(self, data):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

def main():
    print("="*50)
    print(" SPEEDTEST WEBHOOK SERVICE")
    print("="*50)
    print("VPN Control Endpoints:")
    print("  /hooks/vpn-brazil-on")
    print("  /hooks/vpn-usa-on")
    print("  /hooks/vpn-off")
    print("  /hooks/vpn-status")
    print("\nIndividual Test Endpoints:")
    print("  /hooks/test-panama")
    print("  /hooks/test-brazil")
    print("  /hooks/test-usa")
    print("\nComplete Sequences:")
    print("  /hooks/sequence-brazil")
    print("  /hooks/sequence-usa")
    print("  /hooks/test-all")
    print("\nOther:")
    print("  /hooks/results")
    print("="*50)
    print(f"Server: http://192.168.1.5:9001")
    print("="*50 + "\n")
    
    server = http.server.HTTPServer(('192.168.1.5', 9001), Handler)
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        vpn_disconnect()
        print("\nServer terminated.")

if __name__ == "__main__":
    main()
```

### 5.2 Startup Script
Create file `C:\scripts\START_WEBHOOK.bat`:

```batch
@echo off
cd C:\scripts
C:\Users\wilso\AppData\Local\Programs\Python\Python313\python.exe speedtest_webhook.py
```

---

## 6. WINDOWS TASK SCHEDULER CONFIGURATION

### 6.1 Create Task via PowerShell
Run as Administrator:

```powershell
# Create task to start with Windows
schtasks /create /tn "SpeedtestWebhook" /tr "C:\scripts\START_WEBHOOK.bat" /sc onstart /ru SYSTEM /rl highest /f

# Add trigger to restart on failure
$taskName = "SpeedtestWebhook"
$task = Get-ScheduledTask -TaskName $taskName
$task.Settings.RestartInterval = "PT1M"  # 1 minute
$task.Settings.RestartCount = 3
$task | Set-ScheduledTask
```

### 6.2 Useful Task Scheduler Commands

```powershell
# Start manually
schtasks /run /tn "SpeedtestWebhook"

# Check status
schtasks /query /tn "SpeedtestWebhook"

# Stop
schtasks /end /tn "SpeedtestWebhook"

# Delete
schtasks /delete /tn "SpeedtestWebhook" /f
```

---

## 7. AVAILABLE ENDPOINTS

### 7.1 Webhook URLs
Base URL: `http://192.168.1.5:9001`
Token: `UgaJMc9vaJxU7J9GucZ4JvdUbdTahC99`

### 7.2 Endpoint List

| Endpoint | Description | Action |
|----------|-------------|--------|
| `/hooks/test-panama` | Direct Panama test | Speedtest with Ufinet server |
| `/hooks/sequence-brazil` | Brazil sequence | Connect VPN → Test → Disconnect |
| `/hooks/sequence-usa` | USA sequence | Connect VPN → Test → Disconnect |
| `/hooks/test-all` | Complete test | Tests all 3 regions |
| `/hooks/results` | Latest results | Returns JSON with latest measurements |
| `/hooks/vpn-status` | VPN status | Checks if VPN is connected |
| `/hooks/vpn-brazil-on` | Turn on Brazil VPN | Connects to Brazil server |
| `/hooks/vpn-usa-on` | Turn on USA VPN | Connects to Miami server |
| `/hooks/vpn-off` | Turn off VPN | Disconnects any active VPN |

### 7.3 Usage Examples

```powershell
# Simple Panama test
curl "http://192.168.1.5:9001/hooks/test-panama?token=UgaJMc9vaJxU7J9GucZ4JvdUbdTahC99"

# Complete Brazil sequence
curl "http://192.168.1.5:9001/hooks/sequence-brazil?token=UgaJMc9vaJxU7J9GucZ4JvdUbdTahC99"

# Test all regions
curl "http://192.168.1.5:9001/hooks/test-all?token=UgaJMc9vaJxU7J9GucZ4JvdUbdTahC99"

# View latest results
curl "http://192.168.1.5:9001/hooks/results?token=UgaJMc9vaJxU7J9GucZ4JvdUbdTahC99"
```

---

## 8. REACTOR INTEGRATION

### 8.1 Reactor Configuration
In Reactor, configure the following actions:

1. **Complete Hourly Test** (every hour):
   - URL: `http://192.168.1.5:9001/hooks/test-all?token=UgaJMc9vaJxU7J9GucZ4JvdUbdTahC99`
   - Method: GET
   - Timeout: 300 seconds

2. **Individual Panama Test** (every 30 minutes):
   - URL: `http://192.168.1.5:9001/hooks/test-panama?token=UgaJMc9vaJxU7J9GucZ4JvdUbdTahC99`
   - Method: GET
   - Timeout: 120 seconds

### 8.2 JSON Response Example

```json
{
  "success": true,
  "download": 301.97,
  "upload": 150.42,
  "ping": 2.06,
  "server": "Ufinet",
  "timestamp": "2025-09-26T16:33:02.021407"
}
```

---

## 9. MONITORING AND TROUBLESHOOTING

### 9.1 Monitoring Script
For real-time monitoring, create `C:\scripts\speedtest_monitor.py`:

```python
import http.server
import json
import subprocess
import time
import os
from datetime import datetime
from urllib.parse import urlparse, parse_qs

# [Use the same code from main script, but add detailed logs]

def log(msg):
    """Log with timestamp"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"[{timestamp}] {msg}")

# Add log() calls in each important function
```

### 9.2 Check if Service is Running

```powershell
# View Python processes
Get-Process python* | Select-Object Id, ProcessName, StartTime

# Test connectivity
Test-NetConnection -ComputerName 192.168.1.5 -Port 9001

# Check logs
Get-Content C:\scripts\speedtest_results.json -Tail 10
```

### 9.3 Common Issues and Solutions

| Problem | Solution |
|---------|----------|
| HTTP 403 in Speedtest | Reinstall official Speedtest CLI |
| VPN won't connect | Check if ExpressVPN is active |
| Task won't start | Verify Python path in .bat file |
| Webhook not responding | Check firewall on port 9001 |
| Results not saving | Check permissions in C:\scripts |

---

## 10. SECURITY CONFIGURATION

### 10.1 Firewall
Open port in Windows Firewall:

```powershell
New-NetFirewallRule -DisplayName "Speedtest Webhook" -Direction Inbound -Protocol TCP -LocalPort 9001 -Action Allow
```

### 10.2 Security Token
Default token: `UgaJMc9vaJxU7J9GucZ4JvdUbdTahC99`

To change it, edit the `VALID_TOKEN` variable in the Python script.

---

## 11. SERVER INFORMATION

### 11.1 Configured Speedtest Servers
- **Panama:** Ufinet (ID: 31830)
- **Brazil:** Claro Net Virtua SP (ID: 16322)
- **USA:** AT&T Orlando FL (ID: 68862)

### 11.2 ExpressVPN Locations
- **Brazil:** Brazil - 2 (ID: 163)
- **USA:** USA - Miami - 2 (ID: 202)

---

## 12. FINAL TEST

### 12.1 Test Procedure
1. Restart computer
2. Wait 2 minutes
3. Run in PowerShell:

```powershell
# Check if running
Get-Process python*

# Test webhook
Invoke-WebRequest -Uri "http://192.168.1.5:9001/hooks/vpn-status?token=UgaJMc9vaJxU7J9GucZ4JvdUbdTahC99"

# Run complete test
Invoke-WebRequest -Uri "http://192.168.1.5:9001/hooks/test-all?token=UgaJMc9vaJxU7J9GucZ4JvdUbdTahC99"
```

### 12.2 Expected Results
- Panama: ~300 Mbps download / ~150 Mbps upload / ~2ms ping
- Brazil: ~260 Mbps download / ~130 Mbps upload / ~140ms ping
- USA: ~280 Mbps download / ~140 Mbps upload / ~50ms ping

---

## CONCLUSION

The system is ready for use. Webhooks can be called by Reactor or any other automation system that supports HTTP GET requests.

For support or modifications, all files are located in `C:\scripts\`.

---

*Document created: September 2025*
*Version: 1.0*